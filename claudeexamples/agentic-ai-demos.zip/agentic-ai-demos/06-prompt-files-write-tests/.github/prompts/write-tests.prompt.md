---
name: write-tests
description: Write and run unit tests for a Python file, then report any bugs found
argument-hint: Python file to test, e.g. todo.py
agent: agent
tools: ['read', 'search', 'edit', 'execute']
---

Write unit tests for ${input:file:todo.py}.

Follow these steps:

1. Read the file. For every public function, write down what its docstring promises.
2. Create `test_<file name>` in the same folder using Python's built-in `unittest` module. No extra packages.
3. Cover normal cases, edge cases (empty input, bad input, boundaries) and every promise in the docstrings.
4. Run the tests with `python -m unittest -v` (use `py` on Windows if `python` is not found).
5. If a test fails because the code is wrong, do NOT change the code. Report it in a table:
   | Test | What failed | Likely bug | Line |
6. End with one line: "X tests, Y passed, Z failed".
