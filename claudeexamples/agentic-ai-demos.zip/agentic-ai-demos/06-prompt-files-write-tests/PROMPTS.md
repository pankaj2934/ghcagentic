# Demo 6 · Prompt files: reusable slash commands

**Human analogy:** A recipe card or checklist. You write it once, and anyone on the team can follow it the same way every time.
**What it shows:** A `.prompt.md` file in `.github/prompts/` becomes a `/command` in chat. It can ask for input, pick the agent and limit the tools.
**Time:** about 5 minutes. **Needs:** Python 3.10+.

## Files in this folder

| File | What it is |
|---|---|
| `.github/prompts/write-tests.prompt.md` | The reusable prompt. Open it and show the frontmatter: `agent`, `tools`, `${input:file}` |
| `todo.py` | A tiny to-do library with 2 bugs hidden in it |

## Before you start

1. **File → Open Folder…** and pick `06-prompt-files-write-tests`.
2. Open Chat (**Ctrl+Alt+I** / **⌃⌘I**), click **+**.

## Step 1 · Run the slash command

Type `/` in the chat box and point out that `write-tests` is in the list. Then send:

```text
/write-tests
```

When it asks for the file, type `todo.py` (or just press Enter for the default).

**Point out:**

- You typed two words; the prompt file supplied the full, consistent instructions.
- It switched to **Agent** and used only the tools listed in the file.
- It found real bugs (numbering is off by one, empty titles are accepted) and **reported** them instead of hiding them, because the prompt file told it to.

## Step 2 · Now fix what it found

```text
Fix the bugs you reported in todo.py, then run the tests again and show the final result line.
```

## Step 3 · Make your own (talking point)

```text
Create a new prompt file .github/prompts/explain-for-new-joiner.prompt.md that explains any file I pass in plain English for someone in their first week: what it does, how it fits in, and 3 questions they should ask their buddy. Use ${input:file} for the file name.
```

Then try it: `/explain-for-new-joiner` with `todo.py`.

**Key message:** Commit `.github/prompts/` to your repo and every teammate gets the same commands.

## Reset

Delete `test_todo.py` and any new prompt files, and restore `todo.py` with **Restore Checkpoint**.
