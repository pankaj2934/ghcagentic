"""A tiny to-do list library.

Each to-do is a dict: {"title": str, "done": bool}.
Users see to-dos numbered from 1, like a normal list.
"""


def add(todos, title):
    """Add a new to-do and return the list. Raises ValueError if title is empty or only spaces."""
    todos.append({"title": title.strip(), "done": False})
    return todos


def complete(todos, number):
    """Mark to-do number `number` (1-based, as the user sees it) as done."""
    todos[number]["done"] = True
    return todos


def pending(todos):
    """Return the titles of to-dos that are not done yet."""
    return [t["title"] for t in todos if not t["done"]]


def summary(todos):
    """Return a short progress line, e.g. '2 of 5 done'."""
    done = sum(1 for t in todos if t["done"])
    return f"{done} of {len(todos)} done"
