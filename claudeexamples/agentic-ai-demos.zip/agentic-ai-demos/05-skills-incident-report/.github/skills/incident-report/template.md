# Incident report: <short title>

| Field | Value |
|---|---|
| Date (UTC) | |
| Severity | SEV? (matched rule: "...") |
| Duration | first customer impact → full recovery |
| Services affected | |
| Customer impact | |
| Status | Resolved / Monitoring |

## Summary

<under 80 words: what happened, impact, how it was fixed>

## Timeline (UTC)

<table from scripts/timeline.py>

## Root cause

## What went well

## What went wrong

## Action items

| # | Action | Owner | Due | Type (prevent / detect / mitigate) |
|---|---|---|---|---|

## Open questions
