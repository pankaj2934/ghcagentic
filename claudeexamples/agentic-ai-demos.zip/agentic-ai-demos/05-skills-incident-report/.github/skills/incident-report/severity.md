# Severity levels

Pick the highest level whose rule matches.

| Level | Rule |
|---|---|
| SEV1 | A customer-facing service was fully unavailable for more than 15 minutes, OR any data was lost or exposed. |
| SEV2 | A customer-facing service was degraded (error rate above 5% or p95 latency above 2 s) for more than 10 minutes. |
| SEV3 | Minor or internal-only impact, OR customer impact lasted 10 minutes or less. |
