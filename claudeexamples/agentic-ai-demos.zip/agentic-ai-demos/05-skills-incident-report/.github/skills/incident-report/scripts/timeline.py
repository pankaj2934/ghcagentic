"""Turn a service log into a short incident timeline (Markdown table).

Usage:
    python timeline.py <path-to-log>

Keeps only the lines that matter for an incident (deploys, alerts, warnings,
errors, rollbacks, recovery) and collapses repeated messages into one row
with a count.
"""

import re
import sys
from pathlib import Path

LINE = re.compile(r"^(?P<ts>\S+)\s+(?P<level>[A-Z]+)\s+(?P<svc>\S+)\s+(?P<msg>.*)$")
KEYWORDS = ("deploy", "rollback", "alert", "resolved", "recovered", "migration", "page")
IMPORTANT_LEVELS = {"WARN", "ERROR", "CRIT"}


def normalise(message: str) -> str:
    """Strip request-specific numbers so repeated errors group together."""
    message = re.sub(r"/\d+", "/:id", message)
    message = re.sub(r"\b\d+ms\b", "", message)
    return re.sub(r"\s+", " ", message).strip()


def build_rows(lines: list[str]) -> list[list[str]]:
    rows: list[list[str]] = []
    for raw in lines:
        match = LINE.match(raw.strip())
        if not match:
            continue
        level, msg = match["level"], match["msg"]
        if level not in IMPORTANT_LEVELS and not any(k in msg.lower() for k in KEYWORDS):
            continue
        time = match["ts"].replace("T", " ").replace("Z", "")[:16]
        event = f"{level} {match['svc']}: {normalise(msg)}"
        if rows and rows[-1][1] == event:
            rows[-1][2] = str(int(rows[-1][2]) + 1)
            rows[-1][3] = time
        else:
            rows.append([time, event, "1", time])
    return rows


def main() -> None:
    if len(sys.argv) != 2:
        sys.exit("Usage: python timeline.py <path-to-log>")
    path = Path(sys.argv[1])
    if not path.exists():
        sys.exit(f"Log file not found: {path}")
    rows = build_rows(path.read_text(encoding="utf-8").splitlines())
    print("| Time (UTC) | Event | Count | Last seen |")
    print("|---|---|---|---|")
    for time, event, count, last in rows:
        last_seen = last if count != "1" else ""
        print(f"| {time} | {event} | {count} | {last_seen} |")


if __name__ == "__main__":
    main()
