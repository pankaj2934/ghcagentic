---
name: incident-report
description: Writes post-incident reports (postmortems) in our team's standard format. Use when asked to write, draft or summarize an incident report, postmortem, outage summary or RCA from logs, chat notes or timelines.
argument-hint: Path to the incident log, e.g. incidents/checkout-outage.log
---

# Incident report (team standard)

Follow these steps in order.

1. **Build the timeline with the bundled script.** Run:
   `python .github/skills/incident-report/scripts/timeline.py <path-to-log>`
   (on Windows you may need `py` instead of `python`).
   Use its output as the Timeline section. Never invent timestamps.
2. **Read the chat notes** in the same folder as the log for context, decisions and owners.
3. **Pick the severity** using [severity.md](./severity.md). Quote the rule that matched.
4. **Write the report** using exactly the structure in [template.md](./template.md). Keep every heading, in the same order.
5. **Save it** next to the log as `<log-name>-report.md`, then show a 3-line summary in chat.

## Rules

- Blameless: describe systems and decisions, never blame people.
- All times in UTC, 24-hour format.
- Every action item has an owner and a due date. If either is unknown, write `TBD` and list it under "Open questions".
- Keep the summary under 80 words.
