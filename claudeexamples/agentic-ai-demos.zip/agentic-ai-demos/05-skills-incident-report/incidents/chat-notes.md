# #inc-checkout channel export (2 Oct 2026, times UTC)

- 14:03 Priya (payments on-call): Paged. Checkout error rate 18%, all errors are "lock wait timeout on table carts".
- 14:06 Marco (platform): v2.14.0 went out at 13:58. It has migration 0042 that adds an index on `carts`. Could be locking the table.
- 14:09 Priya: Confirmed the migration is still running. It is not online-safe (no CONCURRENTLY).
- 14:12 Sam (eng manager): Customers can browse but cannot pay. Opening status page incident.
- 14:15 Marco: Options: wait for migration (unknown time, table has 40M rows) or roll back. Prefer rollback.
- 14:20 Priya: Agreed, rolling back to v2.13.2 and cancelling the migration.
- 14:27 Marco: Rollback done, lock released.
- 14:31 Priya: Error rate back under 1%. Monitoring.
- 14:45 Sam: Status page resolved. Postmortem owner: Priya. Let's add a CI check that blocks non-online-safe migrations.
- 14:47 Marco: I can take the CI check. Also we should run big migrations outside peak hours.
- 14:50 Sam: Someone should also look at why we only alerted on errors, not on the slow checkouts that started at 14:00.
