# Demo 5 · Skills: knowledge learned at school

**Human analogy:** You learned *how* to write a lab report at school. You don't think about it all day, but when someone asks for one, you know the steps and the format.
**What it shows:** An **Agent Skill** is a folder of know-how (instructions + templates + scripts). Copilot only sees its name and description until a task needs it, then loads the whole thing.
**Time:** about 8 minutes. **Needs:** Python 3.10+.

## Files in this folder

```text
.github/skills/incident-report/
├── SKILL.md            ← the steps and rules ("how we write incident reports")
├── severity.md         ← how to pick SEV1 / SEV2 / SEV3
├── template.md         ← the exact report structure
└── scripts/timeline.py ← a script that turns a log into a timeline table
incidents/
├── checkout-outage.log ← what the systems saw
└── chat-notes.md       ← what the humans said during the incident
```

Open `SKILL.md` and show the **name** and **description** at the top. That description is how Copilot decides when to use the skill.

## Before you start

1. **File → Open Folder…** and pick `05-skills-incident-report`.
2. Open Chat (**Ctrl+Alt+I** / **⌃⌘I**), click **+**, choose **Agent**.

## Step 1 · Ask normally and let the skill load itself

Notice the prompt says nothing about templates, severity rules or scripts:

```text
Write an incident report for the checkout outage. Everything you need is in the incidents folder.
```

**Point out:**

- It reads `SKILL.md` on its own because the task matches the skill's description.
- It **runs the bundled script** (`timeline.py`), so the timeline comes from code, not from the model's imagination.
- The severity quotes a rule from `severity.md`.
- The report in `incidents/checkout-outage-report.md` follows `template.md` heading by heading.
- Action items have owners from the chat notes; anything unknown is marked `TBD`.

## Step 2 · Call the skill by name

Skills also show up as slash commands. New chat (**+**), **Agent**:

```text
/incident-report incidents/checkout-outage.log — keep the summary under 50 words this time.
```

## Step 3 · Skills vs. instructions (talking point)

```text
In two sentences: what is the difference between the incident-report skill in this folder and a .github/copilot-instructions.md file? When would a team use each?
```

**Key message:** Instructions are always on (habits). Skills load **only when needed** (expertise). You can have dozens of skills without filling up the context window.

## Reset

Delete `incidents/checkout-outage-report.md`.
