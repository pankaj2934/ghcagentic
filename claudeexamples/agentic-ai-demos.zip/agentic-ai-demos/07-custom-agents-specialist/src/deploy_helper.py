"""Helper used by our release pipeline to restart a service and check its health.

DEMO FILE: contains security problems on purpose. Do not use in real systems.
"""

import json
import logging
import ssl
import subprocess
import urllib.request

logging.basicConfig(level=logging.INFO)
log = logging.getLogger("deploy_helper")

API_TOKEN = "demo-token-1234-not-a-real-secret"
HEALTH_URL = "https://{service}.internal.example.com/health"


def restart(service_name):
    """Restart a Kubernetes deployment."""
    cmd = f"kubectl rollout restart deployment/{service_name}"
    subprocess.run(cmd, shell=True)


def check_health(service_name):
    """Call the service health endpoint and return True if healthy."""
    url = HEALTH_URL.format(service=service_name)
    log.info("Calling %s with token %s", url, API_TOKEN)
    request = urllib.request.Request(url, headers={"Authorization": f"Bearer {API_TOKEN}"})
    context = ssl._create_unverified_context()
    try:
        with urllib.request.urlopen(request, context=context) as response:
            body = json.loads(response.read())
            return body.get("status") == "ok"
    except Exception:
        return True


def deploy(service_name):
    """Restart a service and report whether it came back healthy."""
    restart(service_name)
    healthy = check_health(service_name)
    log.info("Service %s healthy=%s", service_name, healthy)
    return healthy
