# Demo 7 · Custom agents: specialists with a job description

**Human analogy:** A security reviewer on your team. They have a clear role, a checklist, and they *review* code; they don't commit to your branch. When they're done, they hand off to the developer.
**What it shows:** A `.agent.md` file defines a **role, a set of allowed tools and handoffs**. Two agents passing work to each other is the simplest multi-agent workflow.
**Time:** about 7 minutes. **Needs:** nothing extra.

## Files in this folder

| File | What it is |
|---|---|
| `.github/agents/security-reviewer.agent.md` | The specialist. Open it and show `tools: ['read', 'search']` (no edit, no terminal) and the `handoffs` block |
| `src/deploy_helper.py` | A deploy script with security problems planted on purpose |

## Before you start

1. **File → Open Folder…** and pick `07-custom-agents-specialist`.
2. Open Chat (**Ctrl+Alt+I** / **⌃⌘I**), click **+**.
3. Open the **agent picker** (where it says Agent / Ask / Plan) and choose **Security Reviewer**.

## Step 1 · Ask the specialist for a review

```text
Review src/deploy_helper.py
```

**Point out:** It answers in exactly the format its job description asks for: a severity table and a verdict. Its checklist (secrets, `shell=True`, no timeout, TLS off, swallowed exceptions, secrets in logs) came from the `.agent.md` file, not from your prompt.

## Step 2 · Test the guardrail

```text
Great, please fix finding #1 yourself right now.
```

**Point out:** It can't. It doesn't *have* the edit tool, so it explains it's read-only. Limiting tools is how you make an agent safe for a role.

## Step 3 · Hand off to the builder

Click the **Fix the High findings** button under the answer. It switches to the built-in **Agent** with the prompt already filled in. Press **Enter**.

**Point out:**

- Reviewer → Builder is a two-agent workflow, with you approving the handoff.
- Open the diff and compare it against the review table.

## Step 4 · Optional: review again

Switch the picker back to **Security Reviewer** and send:

```text
Review src/deploy_helper.py again. Which findings are fixed and which are still open?
```

## Reset

**Restore Checkpoint** on your first request, or undo the changes in the Source Control view.
