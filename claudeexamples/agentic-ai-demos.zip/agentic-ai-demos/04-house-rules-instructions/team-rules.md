# Team coding rules (Python)

These are our house rules. Follow them for every piece of Python you write in this repo.

- Target Python 3.10+. Add type hints to every function.
- Give every function a one-line docstring.
- Use the `logging` module for diagnostics. Never use `print()` for anything except the final program output.
- Read files with `pathlib.Path` and `encoding="utf-8"`.
- If an input file is missing, exit with a clear error message, not a stack trace.
- Every script has a `main()` function and uses `argparse` for its inputs (with sensible defaults).
- After writing a script, create a matching `test_<name>.py` using the built-in `unittest` module and run it.
- Finish your reply with a short checklist that shows which of these rules the code follows.
