# Demo 4 · House rules: custom instructions

**Human analogy:** A new joiner reads the team handbook once, then follows it every day without being reminded.
**What it shows:** `.github/copilot-instructions.md` is loaded into **every** chat in the repo. Same prompt, very different result.
**Time:** about 8 minutes. **Needs:** Python 3.10+.

## Files in this folder

| File | What it is |
|---|---|
| `servers.csv` | A small server inventory |
| `team-rules.md` | Our team's Python rules. **Not active yet**; you'll install it in Step 2 |

## Before you start

1. **File → Open Folder…** and pick `04-house-rules-instructions`.
2. Open Chat (**Ctrl+Alt+I** / **⌃⌘I**), click **+**, choose **Agent**.

## Step 1 · Without house rules

```text
Write inventory.py that reads servers.csv and prints every server running an end-of-life OS. Treat these as end-of-life: Ubuntu 18.04, CentOS 7, Windows Server 2012 R2. Run it and show me the output.
```

**Point out:** It works, but it's written the way the model likes, not the way *your team* likes.

## Step 2 · Install the house rules

You can do this by hand (create `.github/copilot-instructions.md` and paste in the contents of `team-rules.md`), or let the agent do it:

```text
Create a .github folder in this workspace and copy team-rules.md into it as copilot-instructions.md. Don't change the content.
```

## Step 3 · Same request, new chat

Click **+** for a **new chat** (instructions are read when a chat starts), choose **Agent**, and paste:

```text
Write inventory_v2.py that reads servers.csv and prints every server running an end-of-life OS. Treat these as end-of-life: Ubuntu 18.04, CentOS 7, Windows Server 2012 R2. Run it and show me the output.
```

**Point out:**

- Open `inventory.py` and `inventory_v2.py` side by side. Look for type hints, docstrings, `logging`, `argparse`, `pathlib`.
- It also wrote `test_inventory_v2.py` and ran it. Nobody asked in the prompt; the rules did.
- Expand **References** under the answer: `copilot-instructions.md` is listed. That's proof it was loaded.
- Commit this file to your repo and the whole team gets the same behaviour.

## Reset

Delete `.github/`, `inventory.py`, `inventory_v2.py` and any `test_*.py` files.

## If the rules don't seem to load

Check the setting **`github.copilot.chat.codeGeneration.useInstructionFiles`** is on, and start a new chat.
