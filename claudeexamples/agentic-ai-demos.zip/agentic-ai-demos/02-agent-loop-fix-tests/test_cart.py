"""Tests for cart.py. These describe the CORRECT behaviour. Do not change them."""

import unittest

from cart import apply_discount, subtotal, total_with_tax

CART = [
    {"name": "mug", "price": 12.50, "qty": 2},
    {"name": "t-shirt", "price": 20.00, "qty": 1},
]


class TestSubtotal(unittest.TestCase):
    def test_empty_cart_is_zero(self):
        self.assertEqual(subtotal([]), 0)

    def test_quantity_is_counted(self):
        self.assertAlmostEqual(subtotal(CART), 45.00)


class TestDiscount(unittest.TestCase):
    def test_save10_takes_10_percent_off(self):
        self.assertAlmostEqual(apply_discount(100, "SAVE10"), 90.00)

    def test_save20_takes_20_percent_off(self):
        self.assertAlmostEqual(apply_discount(100, "SAVE20"), 80.00)

    def test_unknown_code_gives_no_discount(self):
        self.assertAlmostEqual(apply_discount(100, "FREESTUFF"), 100.00)


class TestTotal(unittest.TestCase):
    def test_total_without_code_adds_tax(self):
        self.assertAlmostEqual(total_with_tax(CART), 48.60)

    def test_total_with_code(self):
        self.assertAlmostEqual(total_with_tax(CART, "SAVE10"), 43.74)


if __name__ == "__main__":
    unittest.main()
