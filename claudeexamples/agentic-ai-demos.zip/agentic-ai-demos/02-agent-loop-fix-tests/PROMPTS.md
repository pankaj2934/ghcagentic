# Demo 2 · The agent loop: think → act → check → repeat

**Human analogy:** You fix a bug the same way: run it, read the error, change something, run it again, until it works.
**What it shows:** The agent **loop**. It keeps going on its own until the goal (all tests pass) is met.
**Time:** about 5 minutes. **Needs:** Python 3.10+ (no extra packages).

## Files in this folder

| File | What it is |
|---|---|
| `cart.py` | Shopping-cart pricing with 4 bugs planted on purpose |
| `test_cart.py` | 7 tests that describe the correct behaviour |
| `_reset/cart.py` | A clean copy of the buggy file, to reset the demo |

## Before you start

1. **File → Open Folder…** and pick `02-agent-loop-fix-tests`.
2. Optional: show the failure first. In the terminal run `python -m unittest` (or `py -m unittest` on Windows) and you'll see 6 of 7 tests fail.
3. Open Chat (**Ctrl+Alt+I** / **⌃⌘I**), click **+**, choose **Agent**.

## Step 1 · Give it a goal, not instructions

```text
The tests in this folder are failing. Run them, work out why, and fix cart.py until every test passes. Do not change test_cart.py. When you are done, give me a short table: bug | line | fix.
```

**Point out while it runs:**

- **Think:** it reads both files and forms a plan (watch the to-do list if it shows one).
- **Act:** it runs the tests in the terminal (click **Allow**).
- **Observe:** it reads the failures.
- **Repeat:** it edits `cart.py` and runs the tests again, without you asking.
- Nobody told it *how many* bugs there were. The goal ("all tests pass") decides when it stops.

## Step 2 · Review like a human (human in the loop)

Click the "files changed" summary in the chat to open the diff. Talk through each change before you accept it.

```text
Explain each change you made to cart.py as if I were a new joiner. Was any test wrong, or were all the problems in the code?
```

## Reset

Copy `_reset/cart.py` over `cart.py`, or click **Restore Checkpoint** on your first request.
