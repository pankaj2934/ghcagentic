"""Shopping cart pricing for the demo store.

This file has bugs on purpose. The tests in test_cart.py describe the
correct behaviour. Ask the agent to make the tests pass.
"""

TAX_RATE = 0.08  # 8% sales tax

DISCOUNT_CODES = {
    "SAVE10": 0.10,  # 10% off
    "SAVE20": 0.20,  # 20% off
}


def subtotal(items):
    """Return the cart subtotal.

    items: list of dicts like {"name": "mug", "price": 12.50, "qty": 2}
    """
    total = 0
    for item in items:
        total += item["price"]
    return total


def apply_discount(amount, code):
    """Return the amount after applying a discount code.

    Unknown or empty codes give no discount (the amount is returned unchanged).
    """
    if code not in DISCOUNT_CODES:
        raise ValueError(f"Unknown discount code: {code}")
    return amount * DISCOUNT_CODES[code]


def total_with_tax(items, code=None):
    """Return the final price: subtotal, minus discount, plus tax. Rounded to cents."""
    amount = subtotal(items)
    if code:
        amount = apply_discount(amount, code)
    return round(amount * TAX_RATE, 2)
