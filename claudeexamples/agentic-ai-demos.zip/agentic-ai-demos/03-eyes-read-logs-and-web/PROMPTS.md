# Demo 3 · Eyes: reading your files and the web

**Human analogy:** Before you answer a question at work, you *look*: at the logs, the config, a docs page.
**What it shows:** Read-only tools (read file, search, fetch web page) are the agent's **eyes**. Answers get grounded in real data instead of guesses.
**Time:** about 5 minutes. **Needs:** nothing extra (internet for Step 3).

## Files in this folder

| File | What it is |
|---|---|
| `logs/app.log` | A morning of logs from a fake `orders-api` service |
| `config/app.yaml` | That service's configuration |

## Before you start

1. **File → Open Folder…** and pick `03-eyes-read-logs-and-web`.
2. Open Chat (**Ctrl+Alt+I** / **⌃⌘I**), click **+**, choose **Agent** (or **Ask**; this demo only reads).

## Step 1 · Look at the logs

```text
Read logs/app.log. Group the ERROR and WARN lines by type, count them, and show the top issues in a table: issue | level | count | first seen | last seen. Then tell me which issue is hurting customers the most and why.
```

**Point out:** It opened the file itself. You didn't paste anything. The numbers come from the log, not from memory.

## Step 2 · Connect the dots with the config

```text
Now look at config/app.yaml. For each of the top 3 issues, which setting most likely causes or worsens it? Suggest a new value and explain the trade-off. Don't change any files yet.
```

**Point out:** It links a log symptom (`in_use=5/5`) to a config value (`pool_size: 5`), the way an on-call engineer would. "Don't change any files" keeps it in look-only mode.

## Step 3 · Eyes on the web

```text
Fetch https://code.visualstudio.com/docs/agents/overview and explain it to a beginner in 5 bullet points. Then list the 3 links on that page most worth reading next, and say why.
```

**Point out:** It asks permission before it opens a URL. That approval prompt is a guardrail: you decide what the agent may look at.

## Reset

Nothing to reset. This demo doesn't change any files.
