# Demo 9 · MCP: plug in the tools your team already uses

**Human analogy:** Giving a teammate a login to GitHub and Azure DevOps. They can now look up issues, pull requests, work items and builds themselves.
**What it shows:** Vendors ship ready-made MCP servers. Two lines of config give Copilot access to your real systems, using **your** permissions.
**Time:** about 5 minutes. **Needs:** a GitHub account and/or an Azure DevOps organization. No installs: both are hosted (remote) servers.

> Use a **test or sandbox** project for live demos. The agent acts with your permissions, so anything you can do, it can ask to do.

## Before you start

1. **File → Open Folder…** and pick `09-mcp-connect-github-azure-devops`.
2. Open `.vscode/mcp.json`:
   - **Azure DevOps:** replace `YOUR_ORG_NAME` with your organization (the `contoso` in `dev.azure.com/contoso`). Not using Azure DevOps? Delete the `azure-devops` block.
   - **GitHub:** nothing to change.
3. Click **Start** above each server and sign in when the browser opens.
4. Open Chat (**Ctrl+Alt+I** / **⌃⌘I**), click **+**, choose **Agent**.

## GitHub prompts

Works on any public repo, no access to your org needed:

```text
Using the GitHub tools, list the 5 most recently updated open issues in microsoft/vscode-python. For each, give a one-line summary and say whether it looks like a bug or a feature request.
```

On your own repo (replace OWNER/REPO):

```text
Using the GitHub tools, show my open pull requests in OWNER/REPO. For each, tell me if it's waiting on me, waiting on a reviewer, or has failing checks.
```

## Azure DevOps prompts

Replace PROJECT with one of your projects:

```text
List my Azure DevOps projects.
```

```text
List the work items assigned to me in the current iteration of project PROJECT. Group them by state and flag anything that hasn't been updated in 7 days.
```

```text
Show the last 5 failed pipeline runs in project PROJECT. For each, give the pipeline name, the branch, and the first error message, then suggest which one to look at first.
```

**Point out:**

- It's the same agent as before, with new eyes. Nothing changed in Copilot, only the config file.
- Expand a tool call: it's a normal API call made with **your** identity.
- Write actions (create a work item, comment on a PR) still ask for approval.

## Troubleshooting

- **Server fails to start:** check the org name in the URL, then **MCP: List Servers → Show Output**.
- **Org blocks it:** Copilot Business/Enterprise admins can turn MCP off by policy. Check with your admin.
- Prefer a local Azure DevOps server? See the options in the [azure-devops-mcp README](https://github.com/microsoft/azure-devops-mcp).
