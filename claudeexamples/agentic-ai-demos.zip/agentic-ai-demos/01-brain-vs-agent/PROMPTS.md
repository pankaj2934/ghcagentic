# Demo 1 · A brain alone vs. a brain with hands

**Human analogy:** A smart friend on the phone can *tell* you what to do. A colleague at your desk can *do* it.
**What it shows:** The difference between **Ask** (LLM only, read-only) and **Agent** (LLM + tools).
**Time:** about 5 minutes. **Needs:** Python 3.10+ installed.

## Before you start

1. In VS Code: **File → Open Folder…** and pick this folder (`01-brain-vs-agent`). It is empty on purpose.
2. Open Chat with **Ctrl+Alt+I** (Windows/Linux) or **⌃⌘I** (Mac). Click **+** to start a new chat.

## Step 1 · Brain only (Ask)

In the agent picker, choose **Ask**. (If you don't see Ask, set **Session Target** to **Local** first.)

```text
Write a Python script called temperature.py that converts a list of Celsius readings [-5, 0, 21.5, 37, 100] to Fahrenheit and prints a neat table. Save it in this folder and run it.
```

**Point out:** It writes good code in the chat, but no file appears in the Explorer and nothing runs. The brain can only *talk*.

## Step 2 · Brain + hands (Agent)

Click **+** for a new chat, choose **Agent**, and paste **the same prompt**:

```text
Write a Python script called temperature.py that converts a list of Celsius readings [-5, 0, 21.5, 37, 100] to Fahrenheit and prints a neat table. Save it in this folder and run it.
```

**Point out:**

- `temperature.py` appears in the Explorer (the **edit** tool = hands).
- It asks permission to run a terminal command (the **execute** tool = hands). Click **Allow**.
- It reads the output and confirms it worked (reading tool output = eyes).

## Step 3 · Ask the agent what its "eyes and hands" are

```text
List the tools you can use in this session right now. Group them into a table with three columns: "Eyes (read/observe)", "Hands (change/act)", and "Other". One short line per tool.
```

**Point out:** Tools are just functions the LLM is allowed to call. The LLM decides *which* tool, *when*.

## Reset

Delete `temperature.py`, or hover over your first request in the chat and click **Restore Checkpoint**.
