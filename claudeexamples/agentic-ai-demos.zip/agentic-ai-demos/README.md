# Agentic AI with VS Code + GitHub Copilot: live demos

Ten small, self-contained demos that go with the deck **"Agentic AI: from your brain to VS Code"**.
Each folder is one idea. Open the folder in VS Code, open Copilot Chat, and paste the prompts from its `PROMPTS.md` in order.

## The big idea (one line per demo)

| # | Folder | Human part | AI part | Time | Extra needs |
|---|---|---|---|---|---|
| 1 | `01-brain-vs-agent` | Brain that can only talk | LLM in **Ask** vs. **Agent** | 5 min | Python |
| 2 | `02-agent-loop-fix-tests` | Try, check, try again | The **agent loop** | 5 min | Python |
| 3 | `03-eyes-read-logs-and-web` | Eyes | **Read tools**: files, search, web fetch | 5 min | Internet |
| 4 | `04-house-rules-instructions` | Team handbook / habits | **Custom instructions** | 8 min | Python |
| 5 | `05-skills-incident-report` | Knowledge learned at school | **Agent Skills** (`SKILL.md`) | 8 min | Python |
| 6 | `06-prompt-files-write-tests` | Recipe card / checklist | **Prompt files** (`/commands`) | 5 min | Python |
| 7 | `07-custom-agents-specialist` | Specialist colleague | **Custom agents** + handoffs | 7 min | – |
| 8 | `08-mcp-build-your-own-tool` | New pair of eyes and hands | **MCP**: build your own tool | 10 min | Python + `mcp` |
| 9 | `09-mcp-connect-github-azure-devops` | Login to team systems | **MCP**: GitHub / Azure DevOps | 5 min | Accounts |
| 10 | `10-delegate-to-cloud-agent` | Delegate a ticket | **Copilot cloud agent** → PR | 5 min + wait | Paid plan, GitHub repo |

**Short on time?** Do 1, 2, 5, 7 and 8 (~35 minutes). Start 10 at the beginning so the PR is ready by the end.

## Setup checklist (do this the day before)

- [ ] **VS Code**, latest stable version.
- [ ] **GitHub Copilot** signed in (the Free plan covers demos 1–9; demo 10 needs a paid plan).
- [ ] **Python 3.10+** on your PATH. Check with `python --version` (Windows: `py --version`).
- [ ] For demo 8: `python -m pip install -r 08-mcp-build-your-own-tool/requirements.txt`
- [ ] For demo 9: edit the org name in `09-.../.vscode/mcp.json`, start the servers once and sign in.
- [ ] For demo 10: create the test repo and push `todo.py` (see its `PROMPTS.md`).
- [ ] Do a full dry run of every demo you plan to show. Agents don't give the same answer twice.

## How to run any demo

1. **File → Open Folder…** and pick the demo folder (not this parent folder). Each demo has its own `.github/` config, and VS Code reads it from the folder you open.
2. Open Chat: **Ctrl+Alt+I** (Windows/Linux) or **⌃⌘I** (Mac). Click **+** for a fresh chat.
3. Pick the agent the `PROMPTS.md` says (usually **Agent**). Leave the model on **Auto**, or pick one.
4. Copy a prompt from `PROMPTS.md` and paste it into the chat. Each prompt sits in its own code block; hover over it in Markdown preview (**Ctrl+Shift+V**) to get a copy button.
5. When it asks to run a command or open a URL, read it out loud, then click **Allow**. That *is* the lesson about human-in-the-loop.

## Presenter tips

- Zoom in: **Ctrl+=** a few times, and make the chat panel wide.
- Keep **manual approvals** on for the session. It's slower, but the audience sees every action.
- If a run goes sideways, hover over your first request and click **Restore Checkpoint**. That's a good teaching moment too.
- Results differ run to run. Say so up front: "it's a colleague, not a script".
- Use fake or sandbox data only. Everything here is made up.

## Troubleshooting

| Symptom | Fix |
|---|---|
| No **Ask** in the agent picker | Set **Session Target** to **Local**. |
| Custom agent, prompt or skill doesn't appear | Make sure you opened the *demo folder* itself, then start a new chat. Check the file is under `.github/agents`, `.github/prompts` or `.github/skills/<name>/SKILL.md`. |
| Custom instructions ignored | Enable `github.copilot.chat.codeGeneration.useInstructionFiles` and start a new chat. |
| MCP server won't start | **MCP: List Servers → (server) → Show Output**. Usually the wrong Python or a missing package. |
| `python` not found | Use `py` on Windows, or a full path to your Python. |
| Org policy blocks agent mode / MCP | Copilot Business/Enterprise admins control these. Ask your admin. |

## Folder map

```text
agentic-ai-demos/
├── 01-brain-vs-agent/                 PROMPTS.md
├── 02-agent-loop-fix-tests/           cart.py, test_cart.py, _reset/
├── 03-eyes-read-logs-and-web/         logs/app.log, config/app.yaml
├── 04-house-rules-instructions/       servers.csv, team-rules.md
├── 05-skills-incident-report/         .github/skills/incident-report/, incidents/
├── 06-prompt-files-write-tests/       .github/prompts/write-tests.prompt.md, todo.py
├── 07-custom-agents-specialist/       .github/agents/security-reviewer.agent.md, src/
├── 08-mcp-build-your-own-tool/        ops_server.py, data/ops.json, .vscode/mcp.json
├── 09-mcp-connect-github-azure-devops/ .vscode/mcp.json
└── 10-delegate-to-cloud-agent/        PROMPTS.md (issue text)
```

> VS Code and Copilot change every month. If a menu label here doesn't match your screen, check <https://code.visualstudio.com/docs/agents/overview>. The ideas stay the same even when the buttons move.
