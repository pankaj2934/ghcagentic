# Demo 10 · Delegate to the Copilot cloud agent

**Human analogy:** Handing a well-written ticket to a teammate and getting a pull request back later, while you do something else.
**What it shows:** The **Copilot cloud agent** works in the background on GitHub, in its own environment, and returns a **pull request** for you to review.
**Time:** 5 minutes to start, then it runs on its own (often 10–30 minutes). Start it at the beginning of the session and show the result at the end.
**Needs:** a paid Copilot plan (for Business/Enterprise an admin must enable the cloud agent), and a GitHub repository you can push to.

## Before you start (one-time)

1. Create a new **private** GitHub repo, e.g. `agentic-demo-todo`.
2. Copy `todo.py` from `06-prompt-files-write-tests` into it, commit and push.

## Option A · Assign a GitHub issue to Copilot

Create a new issue in that repo. Title: `Add due dates and an overdue list to todo.py`. Body:

```text
## Goal
Let users give a to-do an optional due date and see which to-dos are overdue.

## Requirements
- add(todos, title, due=None) accepts an optional due date as "YYYY-MM-DD".
- Reject invalid dates with a clear ValueError.
- New function overdue(todos, today) returns titles that are not done and are past their due date.
- Fix any existing bugs you find in todo.py (numbering should be 1-based; empty titles should raise ValueError).

## Definition of done
- Unit tests with the built-in unittest module cover every function, including edge cases.
- All tests pass.
- README.md explains how to use the new functions in 5 lines or fewer.
```

In the **Assignees** box, choose **Copilot**. Watch for the 👀 reaction, then open the pull request it creates to follow its progress.

## Option B · Start it from VS Code

With the repo open in VS Code, open Chat, set **Session Target** to **Cloud**, and paste the same text as the prompt.

## When the PR is ready

- Read the PR description and the session log: you can see its plan and every command it ran.
- Ask for a change by commenting on the PR:

```text
@copilot Please also add a summary() test for an empty list, and keep the README to 5 lines.
```

**Key message:** Local agent = pair programmer you watch. Cloud agent = teammate you delegate to and review. Either way, a human reviews before merge.
