"""ops-demo: a tiny MCP server that gives Copilot new "eyes" on our ops data.

The data is fake and lives in data/ops.json. In real life these functions
would call your monitoring, deployment and paging systems instead.

Run by VS Code automatically (see .vscode/mcp.json). To test by hand:
    python ops_server.py
(it waits silently for an MCP client on stdin; press Ctrl+C to stop)
"""

import json
from pathlib import Path

try:  # MCP Python SDK 2.x
    from mcp.server.mcpserver import MCPServer
except ImportError:  # MCP Python SDK 1.x
    from mcp.server.fastmcp import FastMCP as MCPServer

DATA_FILE = Path(__file__).parent / "data" / "ops.json"

server = MCPServer("ops-demo")


def load() -> dict:
    """Read the (fake) ops data fresh on every call."""
    return json.loads(DATA_FILE.read_text(encoding="utf-8"))


@server.tool()
def get_service_status(service: str = "") -> list[dict]:
    """Current health of our services: status, error rate and p95 latency.

    Pass a service name, or leave it empty to get every service.
    """
    services = load()["services"]
    if service:
        services = [s for s in services if s["name"] == service]
    return services


@server.tool()
def get_recent_deployments(service: str, limit: int = 3) -> list[dict]:
    """Most recent deployments for one service, newest first."""
    deployments = [d for d in load()["deployments"] if d["service"] == service]
    deployments.sort(key=lambda d: d["at"], reverse=True)
    return deployments[:limit]


@server.tool()
def get_on_call(service: str) -> dict:
    """Who is on call (primary and secondary) for the team that owns a service."""
    data = load()
    owner = next((s["team"] for s in data["services"] if s["name"] == service), None)
    if owner is None:
        return {"error": f"Unknown service: {service}"}
    return {"service": service, "team": owner, **data["on_call"][owner]}


if __name__ == "__main__":
    server.run()
