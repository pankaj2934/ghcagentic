# Demo 8 · MCP: build the agent a new pair of eyes

**Human analogy:** Giving a new teammate access to the monitoring dashboard, the deploy history and the on-call rota. Same brain, new things it can see and do.
**What it shows:** **MCP (Model Context Protocol)** is a standard plug for tools. You write a few Python functions; Copilot discovers them and decides when to call them.
**Time:** about 10 minutes. **Needs:** Python 3.10+ and the `mcp` package.

## Files in this folder

| File | What it is |
|---|---|
| `ops_server.py` | A ~60-line MCP server with 3 tools: `get_service_status`, `get_recent_deployments`, `get_on_call` |
| `data/ops.json` | Fake ops data (services, deploys, on-call, runbooks) |
| `.vscode/mcp.json` | Tells VS Code how to start the server |
| `requirements.txt` | `mcp` |

## One-time setup (do this before the session)

In a terminal in this folder:

```text
python -m pip install -r requirements.txt
```

(Windows: use `py -m pip install -r requirements.txt`, and if `python` isn't on your PATH, change `"command": "python"` to `"command": "py"` in `.vscode/mcp.json`.)

## Before you start

1. **File → Open Folder…** and pick `08-mcp-build-your-own-tool`.
2. Open `.vscode/mcp.json`. Click **Start** above `"ops-demo"` (or run **MCP: List Servers** from the Command Palette, pick `ops-demo`, then **Start Server**). Accept the trust prompt.
3. Open Chat (**Ctrl+Alt+I** / **⌃⌘I**), click **+**, choose **Agent**.
4. Optional: click the **Configure Tools** icon in the chat box and show the 3 new `ops-demo` tools.

## Step 1 · An on-call question it couldn't answer before

```text
Which of our services are unhealthy right now? For each one, show what was deployed to it most recently and who I should page. Put it in one table and recommend what to do first.
```

**Point out:**

- It calls **three different tools** and joins the results. You never said which tools to use.
- Expand each tool call to show the input and the JSON that came back.
- The data comes from *our* system (`ops.json`), not from the model's memory.

## Step 2 · The agent builds its own new tool

```text
Add a fourth tool to ops_server.py called get_runbook(service) that returns the runbook URL for a service from data/ops.json. Follow the same style as the other tools. Then tell me to restart the ops-demo server.
```

Restart the server (**MCP: List Servers → ops-demo → Restart Server**), start a **new chat**, choose **Agent**, then:

```text
checkout-api is degraded. Give me the runbook link, the on-call engineer, and the last two deployments, so I can start the incident.
```

**Key message:** If your team has an internal API (CMDB, ticketing, feature flags, cost data), a few dozen lines of Python turn it into a tool every Copilot user can use.

## Reset

Remove `get_runbook` from `ops_server.py` (or **Restore Checkpoint**), then restart the server.

## Troubleshooting

- **Server won't start:** open **MCP: List Servers → ops-demo → Show Output**. Most often it's `ModuleNotFoundError: mcp` (run the setup step with the same Python) or `python` not found (use `py` or a full path).
- **Tools not used:** make sure the server shows as *Running* and the tools are ticked under **Configure Tools**.
